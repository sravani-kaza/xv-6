#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

void
invertcase(char *name)
{
  int l=0;
  while(name[l]!='\0')
  {
    //lowercase to uppercase
    if(name[l] >= 'a' && name[l]<= 'z')
    {
      name[l]=name[l]-32;
    }
    //uppercase to lowercase
    else if(name[l] >= 'A' && name[l]<= 'Z')
    {
      name[l]=name[l]+32;
    }
    else
    {
      //do nothing
    }
    
    l++;
  } 
  printf(1,"%s ",name );
}
int
main(int argc, char *argv[])
{
  int  i;

  if(argc <= 1)
  {
    exit();
  }
  for(i=1;i<argc;i++)
    invertcase(argv[i]);
  exit();
}