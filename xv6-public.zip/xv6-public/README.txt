-->These are the files that are modified files for doing this assignment.

	defs.h
	proc.c
	invertcase.c
	ps.c
	set_priority.c
	syscall.c
	syscall.h
	sysproc.c
	sysproc.h
	user.h
	usys.S
	Makefile
	README.txt
	report.txt
	image1-RR.png
	image2-priority.png

-->The sheduler given initially in round robin sheduling in xv86, it was changed to priority-based sheduler.
-->Sheduler function is in proc.c.
-->ps.c has been written to execute the cps syscall.
-->timepass.c has been written as a benchmark process.
-->set_priority.c was implemented to execute cset_priority syscall. 