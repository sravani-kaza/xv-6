
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
    
    double x,y;
    if(argc < 2)
        y = 1.0;
    else if(argc >= 2 && argc <=10)
        y = 1.5;
    else
        y = 2.0;

    int id = fork();
    if(id < 0)
    {
    	printf(1,"fork failed\n" );
    }
    else if (id == 0) 
    {
        int i=0;
        while(i<20) 
        {
            int j =0;
            while(j<25) 
            {
                double k = 0;
                while(k<999999)
                { 
                    x = x + 8.96 * 3.12 - 1.56 / 2.78;
                    k = k + y - 1;
                }
                j++;
            }
            i++;
        }

        printf(1, "timepass ended\n");
    }
    else
    {   
    	printf(1,"Parent %d created %d\n",getpid(),id );
        wait();
    }
    exit();
}
