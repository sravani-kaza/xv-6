#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int 
main(int argc,char * argv[])
{
	if(argc<3)
	{
		printf(1,"Wrong input\n");
		exit();
	}
	int proc_pid = atoi(argv[1]);
	int proc_priority = atoi(argv[2]);
	cset_priority(proc_pid,proc_priority);
	exit();

}